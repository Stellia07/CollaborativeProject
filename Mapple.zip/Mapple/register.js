const firebaseConfig = {
    apiKey: "AIzaSyD-kHwAMkyVE8bNyh28Hf_H4XKiGevUrNU",
    authDomain: "onlineshop-a19c3.firebaseapp.com",
    databaseURL: "https://onlineshop-98032-default-rtdb.firebaseio.com/",
    projectId: "onlineshop-a19c3",
    storageBucket: "onlineshop-a19c3.appspot.com",
    messagingSenderId: "320653063424",
    appId: "1:320653063424:web:4e3da146082a83e415afe5"
  };
  firebase.initializeApp(firebaseConfig);
  var contactFormDB = firebase.database().ref("MyInfo");
  // register //
  const f_name = document.getElementById('f_name');
  const l_name = document.getElementById('l_name');
  const mail = document.getElementById('mail');
  const mobile = document.getElementById('mobile');
  const address1 = document.getElementById('address1');
  const address2 = document.getElementById('address2');
  const signup_button = document.getElementById('signup_button');
  //________________________________________________//
  const database = firebase.database();
  const rootRef = database.ref('User');
  
  signup_button.addEventListener('mouseover', (e) =>{
      e.preventDefault();
      rootRef.child(f_name.value).set({
        l_name: l_name.value,
        mail: mail.value,
        mobile: mobile.value,
        address1: address1.value,
        address2: address2.value,
      });
  });