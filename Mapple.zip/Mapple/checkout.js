const firebaseConfig = {
    apiKey: "AIzaSyD-kHwAMkyVE8bNyh28Hf_H4XKiGevUrNU",
    authDomain: "onlineshop-a19c3.firebaseapp.com",
    databaseURL: "https://onlineshop-98032-default-rtdb.firebaseio.com/",
    projectId: "onlineshop-a19c3",
    storageBucket: "onlineshop-a19c3.appspot.com",
    messagingSenderId: "320653063424",
    appId: "1:320653063424:web:4e3da146082a83e415afe5"
  };
  firebase.initializeApp(firebaseConfig);
  var contactFormDB = firebase.database().ref("MyInfo");
  
  const fname = document.getElementById('fname');
  const email = document.getElementById('email');
  const adr = document.getElementById('adr');
  const city = document.getElementById('city');
  const state = document.getElementById('state');
  const zip = document.getElementById('zip');
  const cname = document.getElementById('cname');
  const cardNumber = document.getElementById('cardNumber');
  const expdate = document.getElementById('expdate');
  const cvv = document.getElementById('cvv');
  const submit = document.getElementById('submit');
  
  const database = firebase.database();
  const rootRef = database.ref('Checkout');
  
  submit.addEventListener('mouseover', (e) =>{
    e.preventDefault();
    rootRef.child(fname.value).set({
      email: email.value,
      adr: adr.value,
      city: city.value,
      state: state.value,
      zip: zip.value,
      cname: cname.value,
      cardNumber: cardNumber.value,
      expdate: expdate.value,
      cvv: cvv.value
    });

});