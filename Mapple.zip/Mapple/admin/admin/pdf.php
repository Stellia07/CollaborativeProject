<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <title>PDF</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy41WvTNh0E263XmFcJ1SAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <body>
    <style media="screen">
      body{
        background-color: #e9eb
      }
    </style>
    <div class="container">
      <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <div style="background-color: white; border: 1px solid #cccccc; padding: 16px
            ; margin-top: 40px;">
              <center><h3>Sales</h3></center>
              <table class="table table=hover">
                <tr>
                  <th>View Online</th>
                  <th>Download</th>
                </tr>
                <?php
                  $con = new PDO("mysql:host=localhost;dbname=onlineshop","root","");
                  $query = "SELECT * FROM orders_info";
                  $result = $con->prepare($query);
                  $result->execute();
                  if ($result->rowCount()) {
                    // code...
                    $employe=$result->fetch()
                      // code...
                      ?>
                      <tr>
                        <td>
                          <a href="genpdf.php?em_id=<?php echo $employe['order_id'];
                          ?>">View Online</a>
                        </td>
                        <td>
                          <a href="genpdf.php?em_id=<?php echo $employe['order_id'];
                          ?>" download ="genpdf.php?em_id=<?php
                           echo $employe['order_id']; ?>">Download Now</a>
                        </td>
                      </tr>
                      <?php

                  }
                  else {
                    // code...
                    echo "<br><br>Data Not Found";
                  }
                 ?>

              </table>
            </div>
        </div>
          <div class="col-md-3"></div>
      </div>
    </div>
  </body>
</html>
