<?php
include_once 'fpdf/fpdf.php';
$pdf = new FPDF();
$pdf->AddPage();
$pdf-> SetFont("Arial","B",8);
$pdf->setTextColor(302,3,3);
$pdf->Cell(200,20, "Sales","0","1","C");
//table odbc_columns
$con = new PDO("mysql:host=localhost;dbname=onlineshop","root","");
$pdf->setLeftMargin(30);
$pdf->setTextColor(0,0,0);

$pdf->Cell(20,10,"Order Id", "1", "0", "C");
$pdf->Cell(30,10,"User Id", "1", "0", "C");
$pdf->Cell(30,10,"First Name", "1", "0", "C");
$pdf->Cell(30,10,"Email", "1", "0", "C");
$pdf->Cell(30,10,"Address", "1", "0", "C");
$pdf->Cell(30,10,"City", "1", "1", "C");
if (isset($_GET['em_id']))
{
	// code..
	$id = $_GET['em_id'];
	$query = "SELECT * FROM orders_info";
	$result = $con->prepare($query);
	$result->execute();
	if ($result->rowCount()!=0)
	{
		// code...

		while ($employe = $result->fetch()) {
			// code...
			$pdf->Cell(20,10, $employe['order_id'], "1", "0", "C");
			$pdf->Cell(30,10, $employe['user_id'], "1", "0", "C");
			$pdf->Cell(30,10, $employe['f_name'], "1", "0", "C");
			$pdf->Cell(30,10, $employe['email'], "1", "0", "C");
			$pdf->Cell(30,10, $employe['address'], "1", "0", "C");
			$pdf->Cell(30,10, $employe['city'], "1", "1", "C");
    }
  }
}


$pdf->Cell(30,10,"State", "1", "0", "C");
$pdf->Cell(30,10,"Zip", "1", "0", "C");
$pdf->Cell(30,10,"CardName", "1", "0", "C");
$pdf->Cell(30,10,"CardNumber", "1", "0", "C");
$pdf->Cell(30,10,"Exp Date", "1", "0", "C");
$pdf->Cell(30,10,"prod count", "1", "1", "C");

if (isset($_GET['em_id']))
{
	// code..
	$id = $_GET['em_id'];
	$query = "SELECT * FROM orders_info";
	$result = $con->prepare($query);
	$result->execute();
	if ($result->rowCount()!=0)
	{
		// code...

		while ($employe = $result->fetch()) {
			// code...
      $pdf->Cell(30,10, $employe['state'], "1", "0", "C");
      $pdf->Cell(30,10, $employe['zip'], "1", "0", "C");
      $pdf->Cell(30,10, $employe['cardname'], "1", "0", "C");
      $pdf->Cell(30,10, $employe['cardnumber'], "1", "0", "C");
      $pdf->Cell(30,10, $employe['expdate'], "1", "0", "C");
      $pdf->Cell(30,10, $employe['prod_count'], "1", "1", "C");
    }
  }
}


$pdf->Cell(30,10,"Total Amount", "1", "0", "C");
$pdf->Cell(30,10,"Cvv", "1", "1", "C");
if (isset($_GET['em_id']))
{
	// code..
	$id = $_GET['em_id'];
	$query = "SELECT * FROM orders_info";
	$result = $con->prepare($query);
	$result->execute();
	if ($result->rowCount()!=0)
	{
		// code...

		while ($employe = $result->fetch()) {
			// code...
      $pdf->Cell(30,10, $employe['total_amt'], "1", "0", "C");
			$pdf->Cell(30,10, $employe['cvv'], "1", "1", "C");
    }
  }
}


$pdf->Output();

 ?>
