
package com.mycompany.mvcpattern;


public class StudentGeterSeter {
    String stdid;
    String stdname;
    String stdcourse;

    public StudentGeterSeter() {
    }

    public StudentGeterSeter(String stdid, String stdname, String stdcourse) {
        this.stdid = stdid;
        this.stdname = stdname;
        this.stdcourse = stdcourse;
    }

    public String getStdid() {
        return stdid;
    }

    public void setStdid(String stdid) {
        this.stdid = stdid;
    }

    public String getStdname() {
        return stdname;
    }

    public void setStdname(String stdname) {
        this.stdname = stdname;
    }

    public String getStdcourse() {
        return stdcourse;
    }

    public void setStdcourse(String stdcourse) {
        this.stdcourse = stdcourse;
    }
    
}
